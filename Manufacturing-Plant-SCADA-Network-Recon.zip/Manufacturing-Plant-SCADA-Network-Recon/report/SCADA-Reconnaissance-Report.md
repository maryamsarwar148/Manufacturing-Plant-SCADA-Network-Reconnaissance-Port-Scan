# SCADA Network Reconnaissance & Port Scan Report

## 1. Introduction
This project presents an authorized reconnaissance assessment of a simulated manufacturing plant SCADA network. The purpose is to demonstrate basic cybersecurity techniques used to identify hosts, exposed services, and network communication patterns in an isolated lab.

## 2. Objective
The main objectives were:
- Perform host discovery.
- Identify open ports and services.
- Capture and inspect network traffic.
- Identify potential exposure points.
- Recommend defensive controls.

## 3. Lab Environment
The environment consists of simulated SCADA/OT assets using the private lab network `192.168.56.0/24`.

Assets include an engineering workstation, HMI server, PLC simulator, and historian server.

## 4. Methodology

### Step 1 — Host Discovery
Nmap was used in the isolated lab to identify active hosts.

Example:
`nmap -sn 192.168.56.0/24`

### Step 2 — Service Enumeration
Open ports and service information were examined on authorized lab hosts.

Example:
`nmap -sV 192.168.56.20`

### Step 3 — Packet Capture
Wireshark was used to observe traffic between simulated OT assets.

Example filters:
- `tcp.port == 502`
- `ip.addr == 192.168.56.30`

### Step 4 — Documentation
The discovered services and observations were documented and reviewed for possible exposure.

## 5. Results
The simulated environment contained common management, web, database, and industrial-protocol services. Port 502/TCP was identified on the PLC simulator as a representation of Modbus/TCP traffic.

## 6. Potential Exposure Points
- Management interfaces exposed to a broader network than necessary.
- Industrial protocol communication without strong built-in authentication/encryption.
- Unnecessary services increasing attack surface.
- Insufficient segmentation between IT and OT networks.

## 7. Recommendations
1. Isolate OT/SCADA networks using segmentation and firewalls.
2. Restrict management services to dedicated administrative hosts.
3. Disable unnecessary services.
4. Monitor industrial protocol traffic.
5. Use strong authentication and secure management channels.
6. Maintain detailed logging and alerting.
7. Perform security testing only in authorized maintenance windows and lab environments.

## 8. Conclusion
The exercise demonstrated how network reconnaissance, port scanning, and packet analysis can help identify the exposed attack surface of a simulated SCADA environment. The results emphasize the importance of segmentation, least privilege, service minimization, and continuous monitoring in industrial environments.

## 9. Ethical Scope
All activities described in this report are intended for an isolated, authorized educational environment. No real manufacturing plant or production SCADA system was targeted.
