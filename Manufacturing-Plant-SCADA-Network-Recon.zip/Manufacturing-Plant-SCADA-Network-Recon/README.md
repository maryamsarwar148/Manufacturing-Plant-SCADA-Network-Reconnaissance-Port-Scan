# Manufacturing Plant SCADA — Network Reconnaissance & Port Scan

## Project Overview
This project demonstrates an **authorized cybersecurity lab assessment** of a simulated manufacturing plant SCADA network. The assessment focuses on network reconnaissance, Nmap port/service identification, and Wireshark packet analysis.

## Objectives
- Identify hosts in a simulated SCADA network.
- Identify open TCP ports and associated services.
- Capture and inspect network traffic with Wireshark.
- Document potential exposure points.
- Produce a professional reconnaissance report.

## Lab Scope
All addresses and results in this repository are **fictional/simulated lab data** and are not from a real industrial control system.

### Simulated Assets
| Asset | IP Address | Role |
|---|---|---|
| Engineering Workstation | 192.168.56.10 | SCADA engineering station |
| HMI Server | 192.168.56.20 | Human-machine interface |
| PLC Simulator | 192.168.56.30 | Programmable logic controller simulator |
| Historian Server | 192.168.56.40 | Process data historian |

## Tools
- Nmap
- Wireshark
- Kali Linux / Linux lab environment
- VirtualBox (optional)

## Key Findings
The simulated scan identified several exposed services. These results are intended for learning and documentation only.

See:
- `nmap/scan-results.txt`
- `wireshark/packet-analysis.txt`
- `report/SCADA-Reconnaissance-Report.md`

## Ethical Notice
Perform scanning only against systems you own or have explicit authorization to test. Do not use these procedures against production SCADA/ICS infrastructure without written authorization.
